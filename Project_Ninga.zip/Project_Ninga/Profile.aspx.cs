﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace Project_Ninga
{
    public partial class Profile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                string SID = Request.QueryString["myid"];
                lblmyid.Text = SID;
                if (SID != "" && SID != null)
                {

                    DataTable dt = new DataTable();
                    String FileNamez = Server.MapPath("\\Data\\Data.xls");
                    string connectionString = "Provider=Microsoft.Jet.OleDb.4.0; Data Source=" + FileNamez + "; Extended Properties = Excel 8.0; ";
                    //string connectionString = "Driver ={ Microsoft Excel Driver(*.xls)}; READONLY = FALSE; DriverId = 790; Dbq = " + FileNamez +"; ";
                    OleDbConnection Connection = new OleDbConnection(connectionString);
                    Connection.Open();
                    OleDbCommand command1 = new OleDbCommand();
                    command1.Connection = Connection;
                    command1.CommandText = "SELECT * FROM [User$] where [Sorority_ID]=" + SID + ";";
                    OleDbDataAdapter adapter1 = new OleDbDataAdapter();
                    adapter1.SelectCommand = command1;
                    adapter1.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {

                        prolink.HRef = "Profile.aspx?myid=" + dt.Rows[0]["Sorority_ID"].ToString();
                        prohome.HRef = "Home.aspx?myid=" + dt.Rows[0]["Sorority_ID"].ToString();
                        fullname.Value = dt.Rows[0]["CustomerName"].ToString();
                        busscategory.Value = dt.Rows[0]["BusinessCategory"].ToString();
                        busstype.Value = dt.Rows[0]["BusinessType"].ToString();
                        aboutbusiness.Value = dt.Rows[0]["AboutBusiness"].ToString();
                        phone.Value = dt.Rows[0]["ContactNumber"].ToString();
                        email.Value = dt.Rows[0]["EmailContact"].ToString();
                        address.Value = dt.Rows[0]["Address"].ToString();
                        country.Value = dt.Rows[0]["Country"].ToString();

                    }

                    Connection.Close();
                    dt.Dispose();
                    adapter1.Dispose();
                    command1.Dispose();
                    Connection.Dispose();
                }
            }
        }

        protected void update_Click(object sender, EventArgs e)
        {
            //lblmyid
            String FileNamez = Server.MapPath("\\Data\\Data.xls");
            string connectionString = "Provider=Microsoft.Jet.OleDb.4.0; Data Source=" + FileNamez + "; Extended Properties = Excel 8.0; ";
            //string connectionString = "Driver ={ Microsoft Excel Driver(*.xls)}; READONLY = FALSE; DriverId = 790; Dbq = " + FileNamez +"; ";
            OleDbConnection Connection = new OleDbConnection(connectionString);
            Connection.Open();
            OleDbCommand command2 = new OleDbCommand();
            command2.Connection = Connection;
            command2.CommandText = "Update [User$] set [CustomerName]='" + fullname.Value + "',[BusinessCategory]='" + busscategory.Items[busscategory.SelectedIndex].Text + "',[BusinessType]='" + busstype.Items[busstype.SelectedIndex].Text + "',[ContactNumber]=" + phone.Value + ",[EmailContact]='" + email.Value + "',[Address]='" + address.Value  + "',[Country]='" + country.Value + "',[AboutBusiness]='" + aboutbusiness.Value + "' where [Sorority_ID]=" + lblmyid.Text + ";";
            command2.ExecuteNonQuery();
            Connection.Close();
            command2.Dispose();
            Connection.Dispose();

            ClientScript.RegisterStartupScript(this.GetType(), "Details Updated", "alert('" + "Your Details are updated Successfully..." + "');", true);

        }
    }
}