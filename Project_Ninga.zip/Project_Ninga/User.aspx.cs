﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace Project_Ninga
{
    public partial class User : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                string SID = Request.QueryString["Sorority_ID"];
                if (SID != "")
                {
                    DataTable dt = new DataTable();
                    String FileNamez = Server.MapPath("\\Data\\Data.xls");
                    string connectionString = "Provider=Microsoft.Jet.OleDb.4.0; Data Source=" + FileNamez + "; Extended Properties = Excel 8.0; ";
                    //string connectionString = "Driver ={ Microsoft Excel Driver(*.xls)}; READONLY = FALSE; DriverId = 790; Dbq = " + FileNamez +"; ";
                    OleDbConnection Connection = new OleDbConnection(connectionString);
                    Connection.Open();
                    OleDbCommand command1 = new OleDbCommand();
                    command1.Connection = Connection;
                    command1.CommandText = "SELECT * FROM [User$] where [Sorority_ID]=" + SID + ";";
                    OleDbDataAdapter adapter1 = new OleDbDataAdapter();
                    adapter1.SelectCommand = command1;
                    adapter1.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        lblSororityid.Text = dt.Rows[0]["Sorority_ID"].ToString();
                        lblcustomername.Text = dt.Rows[0]["CustomerName"].ToString();
                        lblbusinesscategory.Text = dt.Rows[0]["BusinessCategory"].ToString();
                        lblbusinesstype.Text = dt.Rows[0]["BusinessType"].ToString();
                        lblcontactnumber.Text = dt.Rows[0]["ContactNumber"].ToString();
                        lblemailcontact.Text = dt.Rows[0]["EmailContact"].ToString();
                        lbladdress.Text = dt.Rows[0]["Address"].ToString();
                        lblcountry.Text = dt.Rows[0]["Country"].ToString();
                        lblaboutbusiness.Value = dt.Rows[0]["AboutBusiness"].ToString();
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "Details Not Available", "alert('" + "Selected user Details Not Available in the System..." + "');", true);
                    }

                    Connection.Close();
                    dt.Dispose();
                    adapter1.Dispose();
                    command1.Dispose();
                    Connection.Dispose();
                }
            }
                

        }

        protected void request_Click(object sender, EventArgs e)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "Requested Submitted", "alert('" + "Your Business Request was submitted successfully..." + "');", true);
        }
    }
}